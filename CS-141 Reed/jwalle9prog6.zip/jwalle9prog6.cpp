// jwalle9prog6.cpp : Defines the entry point for the console application.
//

#include <iostream>
using namespace std;

struct Move { //Struct for move including a destination, source, and move number
	int dest;
	int src;
	int moveNum;
};

struct ListNode { // Struct for linked list
	Move * data;
	ListNode * next;
};

char board[5] = { 'X','X',' ','O','O' };
ListNode * head;

void printInfo() {
	cout << "Jacob Waller 673978936" << endl;
	cout << "Minh: Tue 11am" << endl;
	cout << "11/28/2016" << endl;
	cout << "Welcome to the coin swap puzzle." << endl <<
		"Make moves to solve the puzzle where the objective is to swap the" << endl <<
		"place of the pieces on either side of the board.X can only move" << endl <<
		"to the right into an empty square, or can jump to the right over" << endl <<
		"an O into an empty square.Conversely O can only move to the left" << endl <<
		"into an empty square, or can jump to the left over an X into an" << endl <<
		"empty square." << endl << endl << "Press u to undo and x to exit the program" <<
		endl;

}


/*
	Appends the given Move to the end of the linked list
*/
void add(Move * data) {
	ListNode * temp = head;
	if (temp == NULL) {
		head = new ListNode;
		head->data = data;
		head->next = NULL;
		return;
	}
	while (temp->next != NULL) {
		temp = temp->next;
	}
	temp->next = new ListNode;
	temp->next->data = data;
	temp->next->next = NULL;	
}


/*
	Removes the last node in the list and returns the data it contains
*/
Move * pop() {
	Move * tMove;
	ListNode * temp = head;
	if (temp == NULL) {
		return NULL;
	}
	else if (temp->next == NULL) {
		tMove = head->data;
		head = NULL;
		return tMove;
	}
	while (temp->next->next != NULL) {
		temp = temp->next;
	}
	tMove = temp->next->data;
	temp->next = NULL;
	return tMove;
}


/*
	Makes a move, whether it is legal or not
*/
void makeMove(int src, int dest) {
	char temp = board[src];
	board[src] = board[dest];
	board[dest] = temp;
}


/*
	Calculate average of two values
*/
int average(int a, int b) {
	return (a + b) / 2;
}


/*
	Checks if a given Move is valid
*/
bool checkValidMove(Move * tempMove) {
	if (abs(tempMove->dest - tempMove->src) == 1) {
		if ((board[tempMove->src - 1] == 'X' || board[tempMove->src - 1] == 'O') &&
			(board[tempMove->dest - 1] == ' '))
			return true;
	}
	else if (abs(tempMove->dest - tempMove->src) == 2) {
		if ((board[tempMove->src - 1] == 'X' && board[average(tempMove->src, tempMove->dest) - 1] == 'O' && board[tempMove->dest - 1] == ' ') ||
			(board[tempMove->src - 1] == 'O' && board[average(tempMove->src, tempMove->dest) - 1] == 'X' && board[tempMove->dest - 1] == ' '))
			return true;
	}
	else {
		return false;
	}
	return false;
}


/*
	Undoes the last move
*/
void undo() {
	if (head == NULL) {
		cout << "Can't undo first move! Please make a move" << endl;
		return;
	}
	Move * lastMove = pop();
	makeMove(lastMove->dest - 1, lastMove->src - 1);
}


/*
	Prints the linked list
*/
void printList() {
	ListNode * tempNode = head;
	while (tempNode != NULL) {
		cout << tempNode->data->moveNum;
		if (tempNode->next != NULL) {
			cout << "->";
		}
		tempNode = tempNode->next;
	}
	cout << endl << endl;
}


/*
	Prints the board and any other information
*/
void printBoard() {
	cout << endl << " 1 2 3 4 5 " << endl << " ";
	for (int x = 0; x < 5; x++) {
		cout << board[x] << " ";
	}
	cout << "   List: ";
	printList();
}


/*
	Returns true if the game has been won
*/
bool won() {
	return board[0] == 'O'&&board[1] == 'O'&&board[3] == 'X'&&board[4] == 'X';
}

int main() {
	printInfo();

	int moveNum = 1;
	bool over = false;
	
	while (!over) { //Main game loop
		printBoard();
		char destC = '1', srcC;
		cout << moveNum <<": Input source and then destination seperated by a space: ";
		/*
			Input source and check for 'u' and 'x'
			if source isn't 'u' or 'x', then input 
			destination
		*/
		cin >> srcC; 
		if (srcC <= 57 && srcC >= 48) {
			cin >> destC;
		}
		if (srcC == 'u') {
			undo();
			moveNum--;
		}
		else if (srcC == 'x') {
			return 0;
		}
		else {
			//Change chars into ints
			int src = srcC - '0';
			int dest = destC - '0';

			//Error checking for numbers outside of range
			if (src < 1 || src > 5 || dest < 1 || dest > 5) {
				cout << "Please input only numbers between 1 and 5 or \"x\" or \"u\"";
				continue;
			}
			//Create temporary move
			Move * tMove = new Move;
			tMove->dest = dest;
			tMove->src = src;
			tMove->moveNum = moveNum;

			//Before making move, make sure it's valid
			if (checkValidMove(tMove)) {
				cout << "Good move" << endl;
				add(tMove); // Add move to list
				makeMove(tMove->dest - 1, tMove->src - 1); // Make move
				moveNum++; // Add one to moves
			}
			else {
				cout << "Invalid move, please try again!" << endl; //Not a valid move
			}
		}

		if (won()) { //Check if game has been won
			over = true;
			cout << "Good job! You Won!";
		}
	}
	cout << "Done!";
    return 0;
}

